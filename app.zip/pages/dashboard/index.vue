<template>
  <section class="page">
    <Header />
    <UContainer>
      <Placeholder class="h-32" />
    </UContainer>
  </section>
</template>

<script setup></script>

<style scoped>
.page{
  width: 100%;
  height: 100%;
}
</style>
